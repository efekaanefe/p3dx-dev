"""slam controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot

robot = Robot()
TIME_STEP = 64

camera = robot.getDevice('depth_camera')
camera.enable(TIME_STEP)

print("Has getRangeImage?:", hasattr(camera, "getRangeImage"))




